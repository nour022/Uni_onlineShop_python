import tkinter as tk
from tkinter import ttk

def print_increment(event):
    print("Spinbox wurde inkrementiert!")

def print_decrement(event):
    print("Spinbox wurde dekrementiert!")

root = tk.Tk()
root.geometry("500x500")

sb_value = tk.IntVar(value=5)

spinbox = ttk.Spinbox(root, textvariable=sb_value, values=(5, 10, 15, 20, 25), state="readonly")
spinbox.pack()

spinbox.bind("<<Increment>>", print_increment)
spinbox.bind("<<Decrement>>", print_decrement)

label = ttk.Label(root, textvariable=sb_value)
label.pack()

root.mainloop()