import tkinter as tk
import customtkinter as ctk
from tkinter import ttk,END
from PIL import Image, ImageTk
from db_func import DB_data
import os
import math, random

class EinkaufsWagen(tk.Frame):
    def __init__(self, parent):
        super().__init__(parent)
        self.parent = parent
        self.getData = DB_data()
        self.username, self.Budget = self.getData.getUserDaten()[1], self.getData.getUserDaten()[3]
        # Create the menu frame
        menu = tk.Frame(self)
        menu.config(background="#334257", height=100)
        menu.pack(fill="x")

        # Create labels for the menu
        limg = Image.open("Images/HomeBilder/traktor.png").resize((50, 50))
        self.lphoto = ImageTk.PhotoImage(limg)
        label1 = ttk.Label(menu, image=self.lphoto, background="#334257", foreground="#fff")
        label1.pack(side="left", pady=10, padx=30, expand=1)
        label1.bind("<Button 1>", func=self.parent.homePages)
        # Name Label
        page = tk.Label(menu, text="[ E i n K a u f s W a g e n ]", background="#334257", fg="#fff",
                        font=("Arial", 18, "bold"))
        page.pack(side="left", pady=10, expand=1)
        # EinkaufsWagen
        eimg = Image.open("Images/HomeBilder/einkaufswagen.png").resize((50, 50))
        self.ephoto = ImageTk.PhotoImage(eimg)
        label_wg = ttk.Label(menu, image=self.ephoto, background="#334257", foreground="#fff")
        label_wg.pack(side="right", pady=10, padx=30, expand=1)
        label_wg.bind("<Button 1>", func=self.parent.einkaufsWagen)
        # body freme
        bFrame = tk.Frame(self)
        bFrame.pack(fill="both", expand=1)

        # sidebar Frame
        sidebar = tk.Frame(bFrame, background="#cfc5c5", height=800, )
        # sidebar.place(height=800, width=200, x=0, y=0)
        sidebar.pack(fill="y", side="left")
        # TODO hover for button
        btnProfile = ctk.CTkButton(sidebar, text="Profile", width=230)
        btnProfile.pack(pady=2)

        btnHome = ctk.CTkButton(sidebar, text="Home", width=230)
        btnHome.bind("<Button 1>", command=parent.homePages)
        btnHome.pack(pady=2)

        btnDashboard = ctk.CTkButton(sidebar, text="VerkauferDashboard", width=230)
        roll = self.getData.getUserDaten()[2]
        # print(roll)
        if roll != "Verkaufer":
            btnDashboard.configure(state='disabled')
        else:
            btnDashboard.bind("<Button 1>", command=parent.dashBoard)
        btnDashboard.pack(pady=2)
        logout = ctk.CTkButton(sidebar, text="logout", width=230)
        logout.bind("<Button 1>", command=self.logout)
        logout.pack(side="top", expand=2)

        # Cards Frame for all photo
        self.cards = ctk.CTkScrollableFrame(bFrame, height=700, width=700, fg_color="#fff")
        # self.cards.place(x=200, y=0)
        self.cards.pack(fill="y", side="left")
        imgd = Image.open("Images/HomeBilder/delete.png").resize((25, 25))
        self.delet_img = ImageTk.PhotoImage(imgd)

        self.card_data = self.getData.getData_einkaufsWagen()
        # Create cards
        self.photo_list = [0, ]  # List to store PhotoImage objects
        for item in self.card_data:
            card = item
            # print(card)
            img_path = f"./Images/{card[7]}"
            img = Image.open(img_path).resize((250, 250))
            photo = ImageTk.PhotoImage(img)
            self.photo_list.append(photo)  # Store PhotoImage object in the list
            self.creat_cart_w(card)
        # -------------Quittung------#
        self.qutittungNum_var=tk.StringVar()
        self.username_var=tk.StringVar()
        self.username_var.set(str(self.getData.getUserDaten()[1]))
        print(self.getData.getUserDaten()[1])
        x=random.randint(1000,9999)
        self.qutittungNum_var.set(str(x))
        self.f1=tk.Frame(bFrame,bd=2,width=400,height=80,bg="#283747")
        self.f1.pack(side="top",fill="x")
        quittung_nummer=tk.Label(self.f1,text="Quittung Nummer  :",bg="#283747",fg="orange",font=("Perpetua Titling MT",12,"bold")).place(x=3,y=40)
        quittung_entry=tk.Entry(self.f1,bd=2,width=27,textvariable=self.qutittungNum_var,justify="center").place(x=210,y=40)
        username=tk.Label(self.f1,text=" Username\t   :",bg="#283747",font=("Perpetua Titling MT",12,"bold"),fg="orange").place(x=3,y=0)
        username_entry=tk.Entry(self.f1,textvariable=self.username_var,bd=2,width=27,justify="center").place(x=210,y=3)
        
        #--------scroll funktion ---------#
        self.f2=tk.Frame(bFrame,bd=2,width=350,height=400,bg="black")
        self.f2.pack(side="top",fill="x")
        scroll_y=tk.Scrollbar(self.f2,orient="vertical")
        self.textarea=tk.Text(self.f2,yscrollcommand=scroll_y.set,width=50)
        scroll_y.pack(side="right",fill="y")
        scroll_y.config(command=self.textarea.yview)
        self.textarea.pack(fill="x",expand=1)
        self.we(card)
    def we(self,data):
        self.textarea.delete("1.0",END)
        self.textarea.insert(END,"    wilkommen zu unserem Online Shop  ")
        self.textarea.insert(END,"\n=======================================")
        self.textarea.insert(END,f"\nBestelloung Nummer :\t{self.qutittungNum_var.get()}")
        self.textarea.insert(END,f"\nName               :\t{self.username_var.get()}")
        print(data)
        self.textarea.insert(END,"\n=======================================")
        self.textarea.insert(END,f"\nBestelungen  \t   Anzahl\t\t       Preis")
        self.textarea.insert(END,"\n=======================================")
    def creat_cart_w(self, data):
        card = tk.Frame(self.cards, width=700, height=250)
        # image Traktor

        cardImg = tk.Label(card, image=self.photo_list[len(self.photo_list) - 1])
        cardImg.place(x=20, y=10)

        herLabel = tk.Label(card, text=f"Hersteller: {data[1]}", font=("Arial", 18, "bold"))
        herLabel.place(x=280, y=5)
        hr = ttk.Separator(card)
        hr.place(x=280, y=40, width=200, height=10)

        typLabel = tk.Label(card, text=f"Typ: {data[2]}", font=("Arial", 16, ""))
        typLabel.place(x=285, y=50)

        psLabel = tk.Label(card, text=f"Ps: {data[3]}", font=("Arial", 16, ""))
        psLabel.place(x=285, y=80)

        kmHLabel = tk.Label(card, text=f"Km/h: {data[4]} ", font=("Arial", 16, ""))
        kmHLabel.place(x=285, y=110)

        bjLabel = tk.Label(card, text=f"Baujahr: {data[6]}", font=("Arial", 16, ""))
        bjLabel.place(x=285, y=150)

        priceLabel = tk.Label(card, text=f"Preis: {data[5]}")
        priceLabel.place(x=500, y=40, width=150)

        delet_btn = tk.Label(card, image=self.delet_img)
        delet_btn.bind("<Button>",lambda event, data=data: self.button_clicked(data))
        delet_btn.place(x=665, y=10, width=25)

        # print(anzahl_var.get())
        anzahlBox = ttk.Spinbox(card, from_=1, to=20)
        anzahlBox.set(data[-1])
        anzahlBox.place(x=500, y=80, width=150)

        buyBtn = ctk.CTkButton(card, text="Buy this new")
        buyBtn.bind("<Button-1>", lambda event, data=data: self.button_clicked(data))
        buyBtn.place(x=500, y=150)
        hr = ttk.Separator(self.cards)
        hr.pack()
        card.pack()

    def button_clicked(self, e):
        self.deletCart(e)

    def logout(self, e):
        file_path = "./Daten/login.csv"
        os.remove(file_path)
        self.parent.updateLogin(e)

    def deletCart(self,arr):
        self.getData.delet_order(arr[0])
        self.parent.einkaufsWagen(None)

# if __name__ == "__main__":
#     root = tk.Tk()
#     root.geometry("1350x800+1+1")
#     root.resizable(width=False, height=False)
#     obj = EinkaufsWagen(root)
#     obj.pack(fill="both",expand=1)
#     root.mainloop()
