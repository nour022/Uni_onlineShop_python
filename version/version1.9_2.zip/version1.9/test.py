import tkinter as tk
from PIL import ImageTk, Image
from tkinter import END, ttk
from tkinter import messagebox
from db_func import DB_data

import math, random



class mainpage():
    def __init__(self, root1):

        self.root1 = root1
        self.root1.geometry("1300x700+30+10")
        self.root1.resizable(False, False)
        self.root1.title("Online Shop")
        self.getData = DB_data()
        # self.root1.iconbitmap("logo_ico.ico")
        # -----variablen----------#
        self.qutittungNum_var = tk.StringVar()
        x = random.randint(1000, 9999)
        self.qutittungNum_var.set(str(x))
        title = tk.Label(self.root1, text="Online Shop", bg="#283747", font=("Perpetua Titling MT", 14, "bold"),
                         fg="white").pack(fill="x")
        f1 = tk.Frame(self.root1, bd=2, width=338, height=150, bg="#283747")
        f1.place(x=960, y=32)
        tit = tk.Label(f1, text="infos Käufer :", bg="#283747", fg="orange",
                       font=("Perpetua Titling MT", 14, "bold")).place(x=3, y=0)
        username = tk.Label(f1, text="Username", bg="#283747", font=("Arial", 10, "bold"), fg="whitesmoke").place(x=3,
                                                                                                                  y=50)
        username_entry = tk.Entry(f1, bd=2, width=20).place(x=105, y=50)
        quittung_nummer = tk.Label(f1, text="Qutittung Num", bg="#283747", font=("Arial", 10, "bold"),
                                   fg="whitesmoke").place(x=3, y=80)
        quittung_entry = tk.Entry(f1, bd=2, width=20, textvariable=self.qutittungNum_var, justify="center").place(x=105,
                                                                                                                  y=80)
        search_btn = tk.Button(f1, text="search", font=("Arial", 11, "bold"), width=8, height=2, bg="white").place(
            x=240, y=50)
        # --------Quittung-----------#
        tit1 = tk.Label(f1, text="[ Quittungen ]", font=("Arial", 12, "bold"), bg="#283747", fg="gold").place(x=110,
                                                                                                              y=120)
        f2 = tk.Frame(root1, bd=2, width=338, height=400, bg="white")
        f2.place(x=960, y=185)
        # --------scroll funktion ---------#
        scroll_y = tk.Scrollbar(f2, orient="vertical")
        self.textarea = tk.Text(f2, yscrollcommand=scroll_y.set, width=39)
        scroll_y.pack(side="right", fill="y")
        scroll_y.config(command=self.textarea.yview)
        self.textarea.pack(fill="x", expand=1)
        # -----quittung-----------#
        f3 = tk.Frame(root1, bd=2, width=600, height=115, bg="#283747")
        f3.place(x=700, y=580)
        rechnung_btn = tk.Button(f3, text="Rechnung", width=13, height=1, font="Arial", bg="gold")
        rechnung_btn.place(x=470, y=10)
        rechnung_export_btn = tk.Button(f3, text="exportieren", width=13, height=1, font="Arial", bg="gold",
                                        command=self.save)
        rechnung_export_btn.place(x=470, y=49)
        clear_btn = tk.Button(f3, text="clear table", width=13, height=1, font="Arial", bg="gold")
        clear_btn.place(x=340, y=10)
        exit = tk.Button(f3, text="exit", width=13, height=1, font="Arial", bg="gold")
        exit.place(x=340, y=49)

        self.we()

    def we(self):
        self.textarea.delete("1.0", END)
        self.textarea.insert(END, "   wilkommen zu unserem Online Shop")
        self.textarea.insert(END, "\n=======================================")
        self.textarea.insert(END, f"\nBestelloung Nummer :\t{self.qutittungNum_var.get()}")
        unsername = self.getData.getUserDaten()[0]
        self.textarea.insert(END, f"\nName: {unsername}")
        self.textarea.insert(END, "\n=======================================")
        self.textarea.insert(END, f"\nBestelungen: Claas_195E  \t   Anzahl\t\t       Preis")
        self.textarea.insert(END, "\n=======================================")

    def save(self):
        op = messagebox.askyesno("save", "möchtest du die Quittung speichern?!")
        if op > 0:
            self.bb = self.textarea.get("1.0", END)
            f1 = open('./Daten/quttungNum' + str(self.qutittungNum_var.get()) + ".txt", "w",
                      encoding="utf-8")
            f1.write(self.bb)
            f1.close()

        else:
            return


root1 = tk.Tk()
ob1 = mainpage(root1)
root1.mainloop()