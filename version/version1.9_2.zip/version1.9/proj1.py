import tkinter as tk
from PIL import ImageTk, Image
from tkinter import END, ttk, messagebox, filedialog
from db_func import DB_data
import math, os


class Home:
    # -----------Das Haupt Fenster-----------#
    def __init__(self, root):
        self.getData = DB_data()
        self.root = root
        self.root.geometry("1350x800+1+1")
        self.root.title("Online Shop")
        self.root.configure(background="silver")
        self.root.resizable(False, False)
        title = tk.Label(self.root, text="[  H o m e   P a g e  ]", bg="#283747",
                         font=("Perpetua Titling MT", 14, "bold"), fg="white")
        title.pack(fill="x", padx=30, pady=5)
        # --------variable----------#
        self.search_var = tk.StringVar()  # search_entry
        self.search_by = tk.StringVar()  # search combobox
        self.id_var = tk.StringVar()
        self.hersteller_var = tk.StringVar()
        self.typ_var = tk.StringVar()
        self.leistung_var = tk.StringVar()
        self.km_h_var = tk.StringVar()
        self.preis_var = tk.StringVar()
        self.baujahr_var = tk.StringVar()
        self.auflager_var = tk.StringVar()
        self.delete_produk_var = tk.StringVar()
        self.photo_var = tk.StringVar()

        # ------------frame für den angemeldete person-----------#
        infos_frame = tk.Frame(self.root, bg="white")
        infos_frame.place(x=1053, y=40, width=265, height=90)
        # ---user name label---#
        label_id = tk.Label(infos_frame, text="[ A D M I N ]", bg="white",
                            font=("Perpetua Titling MT", 10, "bold")).place(x=15, y=2)
        self.getusername = tk.StringVar()
        userDaten = self.getData.getUserDaten()
        self.getusername.set(userDaten[1])  # To_Do der eingelogte Nutzer name
        entry_id = tk.Label(infos_frame, textvariable=self.getusername, width=13, font=("Arial", 10, "bold"),
                            relief="solid").place(x=150, y=2)
        # ----start budgeet label----#
        label_startbudget = tk.Label(infos_frame, text="[ B u d g e t ]", bg="white",
                                     font=("Perpetua Titling MT", 10, "bold")).place(x=10, y=30)
        self.getStartbudget = tk.IntVar()
        self.getStartbudget.set(userDaten[3])  # To_Do der eingelogte Nutzer start budget
        entry_startbudget = tk.Label(infos_frame, textvariable=self.getStartbudget, width=13,
                                     font=("Arial", 10, "bold"), relief="solid").place(x=150, y=30)

        # ---------logout/login-----------#
        self.log = tk.StringVar()
        self.update_login_button()
        btn_logout = tk.Button(infos_frame, textvariable=self.log, fg="red", bg="white", font=("Arial", 10, "bold"),
                               width=10, command=self.update_login_button, activebackground="black",
                               activeforeground="white").place(x=90, y=60)

    def update_login_button(self):
        if self.getusername.get() == "":
            self.log.set("[ L o g i n ]")  # To-Do wenn Login dann zum anmelde seite.
        else:
            self.log.set("[ L o g o u t ]")
        # -----------Verkäufer frame------------#
        control_Frame = tk.Frame(self.root, bg="white")
        control_Frame.place(x=1053, y=135, width=265, height=240)
        contro_panel = tk.Label(control_Frame, text="[ V e r k ä u f e r ]", bg="#283747", fg="white",
                                font=("Perpetua Titling MT", 10, "bold"), relief="solid").pack(fill="x", ipady=1)
        add_broduk = tk.Button(control_Frame, text="Add produckt", bg="#85929E", fg="white",
                               command=self.add_pruduk).place(x=33, y=25, width=200, height=30)
        dele_broduk = tk.Button(control_Frame, text="Delete produckt", bg="#85929E", fg="white",
                                command=self.delete_produk).place(x=33, y=60, width=200, height=30)
        update_broduk = tk.Button(control_Frame, text="Update produckt", bg="#85929E", fg="white",
                                  command=self.upd_prod).place(x=33, y=95, width=200, height=30)
        clear_broduk = tk.Button(control_Frame, text="Clear table", bg="#85929E", fg="white", command=self.clear).place(
            x=33, y=130, width=200, height=30)
        about_broduk = tk.Button(control_Frame, text="About us", bg="#85929E", fg="white", command=self.about_us).place(
            x=33, y=165, width=200, height=30)
        exit_broduk = tk.Button(control_Frame, text="Exit", bg="#85929E", fg="white", command=root.quit).place(x=33,
                                                                                                               y=200,
                                                                                                               width=200,
                                                                                                               height=30)
        # ------informationen hinzufügen----------#

        produckt_details = tk.Frame(self.root, bg="white")
        produckt_details.place(x=1053, y=380, width=265, height=356)
        details_panel = tk.Label(produckt_details, text="[ I n f o s ]", bg="#283747", fg="white",
                                 font=("Perpetua Titling MT", 10, "bold"), relief="solid", width=26).grid(column=0,
                                                                                                          row=0,
                                                                                                          columnspan=2,
                                                                                                          sticky="ewns",
                                                                                                          ipady=2)

        id_lbl = tk.Label(produckt_details, text="I D :", bg="white").grid(column=0, row=1, pady=5)
        id_entry = tk.Entry(produckt_details, textvariable=self.id_var, bd=2, width=25).grid(column=1, row=1)

        hersteller_lbl = tk.Label(produckt_details, text="H e r s t e l l e r :", bg="white").grid(column=0, row=2,
                                                                                                   pady=5)
        hersteller_entry = tk.Entry(produckt_details, textvariable=self.hersteller_var, bd=2, width=25).grid(column=1,
                                                                                                             row=2)

        typ_lbl = tk.Label(produckt_details, text="T y p :", bg="white").grid(column=0, row=3, pady=5)
        typ_entry = tk.Entry(produckt_details, textvariable=self.typ_var, bd=2, width=25).grid(column=1, row=3)

        leistung_lbl = tk.Label(produckt_details, text="L e i s t u n g (PS):", bg="white").grid(column=0, row=4,
                                                                                                 pady=5)
        leistung_entry = tk.Entry(produckt_details, textvariable=self.leistung_var, bd=2, width=25).grid(column=1,
                                                                                                         row=4)

        km_h_lbl = tk.Label(produckt_details, text="K m / h :", bg="white").grid(column=0, row=5, pady=5)
        km_h_entry = tk.Entry(produckt_details, textvariable=self.km_h_var, bd=2, width=25).grid(column=1, row=5)

        preis_lbl = tk.Label(produckt_details, text="P r e i s :", bg="white").grid(column=0, row=6, pady=5)
        preis_entry = tk.Entry(produckt_details, textvariable=self.preis_var, bd=2, width=25).grid(column=1, row=6)

        baujahr_lbl = tk.Label(produckt_details, text="B a u j a h r :", bg="white").grid(column=0, row=7, pady=5)
        baujahr_entry = tk.Entry(produckt_details, textvariable=self.baujahr_var, bd=2, width=25).grid(column=1, row=7)

        auflager_lbl = tk.Label(produckt_details, text="A u f  L a g e r :", bg="white").grid(column=0, row=8, pady=5)
        auflager_entry = tk.Entry(produckt_details, textvariable=self.auflager_var, bd=2, width=25).grid(column=1,
                                                                                                         row=8)

        del_prod_lbl = tk.Label(produckt_details, text="del prod bei ID:", bg="white", font=("Arial", 8),
                                fg="red").grid(column=0, row=9, pady=5)
        del_prod_entry = tk.Entry(produckt_details, textvariable=self.delete_produk_var, bd=2, width=25).grid(column=1,
                                                                                                              row=9)

        img_label = tk.Label(produckt_details, text="I M A G E :", bg="white").grid(column=0, row=10, pady=5)
        img_btn = tk.Button(produckt_details, textvariable=self.photo_var, width=21, bg="#85929E", fg="white",
                            activebackground="black", activeforeground="white", command=self.uploadProduct).grid(
            column=1, row=10, pady=5)

        # -------------search Frame-------------#
        search_frame = tk.Frame(self.root, bg="white")
        search_frame.place(x=30, y=40, width=1017, height=40)
        search_lbl = tk.Label(search_frame, text="Suche nach Farhrzeug :", bg="white").place(x=4, y=10)
        combo_search = ttk.Combobox(search_frame, justify="left", textvariable=self.search_by)
        combo_search["value"] = ("ID", "Hersteller", "Typ", "Leistung (PS)", "Km/h", "Preis", "Baujahr", "Auf Lager")
        combo_search.place(x=140, y=10, height=20)
        search_entry = tk.Entry(search_frame, textvariable=self.search_var, bd=2).place(x=290, y=10, height=20)
        search_button = tk.Button(search_frame, text="Search", bg="#85929E", fg="white", activebackground="black",
                                  activeforeground="white", command=self.search).place(x=420, y=10, width=100,
                                                                                       height=20)
        reset_button = tk.Button(search_frame, text="Reset", bg="#85929E", fg="white", activebackground="black",
                                 activeforeground="white", command=self.reset).place(x=525, y=10, width=100, height=20)
        # ---------hauptFrame----------#
        hp_frame = tk.Frame(self.root, bg="white")
        hp_frame.place(x=30, y=85, width=1017, height=700)
        # -------------scroll zum frame hinzufügen-----------#
        scroll_y = tk.Scrollbar(hp_frame, orient="vertical")
        scroll_x = tk.Scrollbar(hp_frame, orient="horizontal")
        scroll_x.pack(side="bottom", fill="x")
        scroll_y.pack(side="right", fill="y")

        # ------tabelle-------#
        self.produckt_table = ttk.Treeview(hp_frame, columns=(
            "ID", "Hersteller", "Typ", "Leistung (PS)", "Km/h", "Preis", "Baujahr", "Auf Lager", "Art"),
                                           yscrollcommand=scroll_y.set, xscrollcommand=scroll_x.set)
        self.produckt_table.place(x=1, y=1, width=1001, height=680)
        self.produckt_table["show"] = "headings"
        self.produckt_table.heading("ID", text="ID")
        self.produckt_table.heading("Hersteller", text="Hersteller")
        self.produckt_table.heading("Typ", text="Typ")
        self.produckt_table.heading("Leistung (PS)", text="Leistung (PS)")
        self.produckt_table.heading("Km/h", text="Km/h")
        self.produckt_table.heading("Preis", text="Preis")
        self.produckt_table.heading("Baujahr", text="Baujahr")
        self.produckt_table.heading("Auf Lager", text="Auf Lager")
        self.produckt_table.heading("Art", text="Art")
        self.produckt_table.column("ID", width=30, anchor="center")
        self.produckt_table.column("Hersteller", width=120, anchor="center")
        self.produckt_table.column("Typ", width=100, anchor="center")
        self.produckt_table.column("Leistung (PS)", width=60, anchor="center")
        self.produckt_table.column("Km/h", width=60, anchor="center")
        self.produckt_table.column("Preis", width=60, anchor="center")
        self.produckt_table.column("Baujahr", width=40, anchor="center")
        self.produckt_table.column("Auf Lager", width=30, anchor="center")
        self.produckt_table.column("Art", width=30, anchor="center")
        self.produckt_table.bind("<ButtonRelease-1>", self.select_row)
        # ---------sql-add produckt---------#
        self.visualisieren()  # auf die tabelle zeigen

    def add_pruduk(self):
        # connect=pymysql.connect(
        #     host="localhost",
        #     user="root",
        #     password="",
        #     database="pruduckte"
        #     )
        # cur=connect.cursor()
        # cur.execute("insert into produckt1 values(%s,%s,%s,%s,%s,%s,%s,%s)",(self.id_var.get()))
        # connect.commit() # connect.close()
        if len(self.hersteller_var.get()) != 0 and len(self.typ_var.get()) != 0 and len(
                self.leistung_var.get()) != 0 and self.photo_var.get() != "Upload Photo" and len(
            self.km_h_var.get()) != 0 and len(self.preis_var.get()) != 0 and len(self.baujahr_var.get()) != 0 and len(
            self.auflager_var.get()) != 0:
            self.getData.insert_card(self.hersteller_var.get(), self.typ_var.get(), self.leistung_var.get(),
                                     self.km_h_var.get(), self.preis_var.get(), self.baujahr_var.get(),
                                     self.auflager_var.get(), self.photo_var.get(), self.getData.getUserDaten()[1])
            self.visualisieren()
            self.save_img(self.file_path)
            self.clear()  # alle tabellen leereen
            messagebox.showinfo("info!!", "alles hat geklappt produckt wurde hinzugefügt")
        else:
            messagebox.showerror(message="Achtung deine angaben ist nicht voll ständig")

    # ---------auf die tabelle zeigen(alle hizufefügte produckte zeigen)------------#
    def visualisieren(self):
        # connect=pymysql.connect(
        #     host="localhost",
        #     user="root",
        #     password="",
        #     database="pruduckte"
        # )
        # cur=connect.cursor()
        # cur.execute("select * from produckt1")
        #     connect.commit()
        # connect.close()
        rows = self.getData.getData_card()
        if len(rows) != 0:
            self.produckt_table.delete(*self.produckt_table.get_children())
            for item in rows:
                self.produckt_table.insert("", END, values=item)
                # limg = Image.open("Images/HomeBilder/traktor.png").resize((50, 50))
                # lphoto = ImageTk.PhotoImage(limg)
                # self.produckt_table.insert('', 'end', values=lphoto)

        self.clear()

    # ---------delete pruduckt---------#
    def delete_produk(self):
        # connect=pymysql.connect(
        #     host="localhost",
        #     user="root",
        #     password="",
        #     database="pruduckte"
        # )
        # cur=connect.cursor()
        # cur.execute("delete from produckt1 where ID=%s",self.delete_produk_var.get())
        # connect.commit()
        # self.visualisieren()
        # connect.close()
        confirm = messagebox.askyesno("Bestätigen", "Möchten Sie wirklich alle Daten löschen?")
        if confirm:
            self.getData.delet_card(self.delete_produk_var.get())
            self.delet_img(f"{self.photo_var.get()}")
            self.visualisieren()

    # --------alle entry felder leeren---------#
    def clear(self):
        # confirm = messagebox.askyesno("Bestätigen", "Möchten Sie neu beginnen?")
        # if confirm:
        self.id_var.set("")
        self.auflager_var.set("")
        self.baujahr_var.set("")
        self.leistung_var.set("")
        self.hersteller_var.set("")
        self.km_h_var.set("")
        self.delete_produk_var.set("")
        self.typ_var.set("")
        self.preis_var.set("")
        self.photo_var.set("Upload Photo")

    # ---------ein row in der table auszuwählen---------#
    def select_row(self, event):
        selectRow = self.produckt_table.focus()
        row = self.produckt_table.item(selectRow)  # infos in ein row speichern in die variable row
        items = row["values"]
        try:
            self.id_var.set(items[0])
            self.hersteller_var.set(items[1])
            self.typ_var.set(items[2])
            self.leistung_var.set(items[3])
            self.km_h_var.set(items[4])
            self.preis_var.set(items[5])
            self.baujahr_var.set(items[6])
            self.auflager_var.set(items[7])
            self.delete_produk_var.set(items[0])
            self.photo_var.set(items[-2])
        except IndexError:
            pass

    # ---------update funktion um produckte zu bearbeiten--------
    def upd_prod(self):
        # connect=pymysql.connect(
        #     host="localhost",
        #     user="root",
        #     password="",
        #     database="pruduckte"
        # )
        # cur=connect.cursor()
        # connect.commit()
        # connect.close()
        # #--------search funktion----------#
        # cur.execute("update produckt1 set Hersteller=%s, Typ=%s , `Leistung (PS)`=%s, `Km/h`=%s, Preis=%s , Baujahr=%s , `Auf Lager`=%s Where ID=%s",())
        confirm = messagebox.askyesno("Bestätigen", "Möchten Sie wirklich alle Daten Updaten?")
        if confirm:
            self.getData.update_card(self.hersteller_var.get(), self.typ_var.get(), self.leistung_var.get(),
                                     self.km_h_var.get(), self.preis_var.get(), self.baujahr_var.get(),
                                     self.auflager_var.get(), self.photo_var.get(), self.id_var.get())
            self.visualisieren()
            self.save_img(self.file_path)
            self.delet_img(f"{self.img_extra}")
            self.clear()

    def search(self):
        # connect=pymysql.connect(
        #     host="localhost",
        #     user="root",
        #     password="",
        #     database="pruduckte"
        # )
        # cur=connect.cursor()
        # cur.execute("select * from produckt1 where `" + str(self.search_by.get())+ "` LIKE '%"+str(self.search_var.get())+"%'")
        # rows= cur.fetchall()

        #     connect.commit()
        # connect.close()
        rows = self.getData.search(str(self.search_by.get()), str(self.search_var.get()))
        if len(rows) != 0:
            self.produckt_table.delete(*self.produckt_table.get_children())
            for item in rows:
                self.produckt_table.insert("", END, values=item)

    def reset(self):
        self.visualisieren()

    def about_us(self):
        messagebox.showinfo("devolpers Amer, nour, theodore",
                            "this is a software for selling vehicles and thier Equipments ")

    def upd_auflager(self):
        # connect=pymysql.connect(
        #     host="localhost",
        #     user="root",
        #     password="",
        #     database="pruduckte"
        # )
        # cur=connect.cursor()
        # bb = self.auflager_var.get()
        # b2 = int(bb)+2 # to-Do statt 2 ein zähl variable
        # self.auflager_var.set(b2)
        # cur.execute("update produckt1 set `Auf Lager`=%s Where ID=%s",(self.auflager_var.get(),self.id_var.get()))
        # connect.commit()
        # self.visualisieren()
        # self.clear()
        # connect.close()
        pass

    def uploadProduct(self):
        self.img_extra = self.photo_var.get()
        types = [("images", "*.png"), ("images", "*.jpg")]
        # Öffne einen Dateidialog, um das Bild auszuwählen
        self.file_path = filedialog.askopenfilename(filetypes=types)
        original_filename = self.file_path.split("/")[-1]
        self.photo_var.set(original_filename)

    def save_img(self, file_path):
        # Überprüfe, ob eine Datei ausgewählt wurde
        if file_path:
            # Öffne das ausgewählte Bild mit Pillow
            image = Image.open(file_path)

            # Erzeuge eine Kopie des Bildes
            image_copy = image.copy()
            # image.r
            # Speicherort für die Kopie
            save_directory = "images"

            # Generiere einen Dateiname für die Kopie
            original_filename = file_path.split("/")[-1]
            filename, extension = original_filename.split(".")
            save_path = f"{save_directory}/{filename}.{extension}"

            # Speichere die Kopie in einer neuen Datei
            image_copy.save(save_path)

            # Schließe das Bild
            image.close()

    def delet_img(self, imgName):
        path = "images"
        imge_path = f"./{path}/{imgName}"
        try:
            os.remove(imge_path)
        except FileNotFoundError:
            pass


# pyinstaller.exe --onefile --windowd -i "logo_file.ico" "name projeckt"
if __name__ == "__main__":
    root = tk.Tk()
    obj = Home(root)
    obj.photo_var.set("Upload Photo")
    # obj.uploadProduct()
    root.mainloop()
