import tkinter as tk
from tkinter import ttk
from PIL import Image, ImageTk
def print_increment(event):
    print("Spinbox wurde inkrementiert!")

def print_decrement(event):
    print("Spinbox wurde dekrementiert!")

root = tk.Tk()
root.geometry("500x500")

frameSecseful= tk.Frame(root)
frameSecseful.place(y=10,x=10,width=300,height=40)

img = Image.open("Images/HomeBilder/checked.png").resize((20, 20))
photoS = ImageTk.PhotoImage(img)
pfile = tk.Label(frameSecseful,image=photoS)
pfile.pack(side="left",expand=1,padx=5)

added = tk.Label(frameSecseful,text="Deine produkt schon in einkaufsWagen!")
added.pack(side="left",expand=1)

root.after(2000, frameSecseful.destroy)
root.mainloop()