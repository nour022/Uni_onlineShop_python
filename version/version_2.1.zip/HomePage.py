import tkinter as tk
from tkinter import ttk
from PIL import Image, ImageTk
import customtkinter as ctk
from db_func import DB_data

font_h1 = ("Helvetica", 22, "bold")
font_p = ("Helvetica", 16, "")


class HomePage(tk.Frame):
    def __init__(self, parent):
        super().__init__(parent)
        self.parent = parent
        self.getData = DB_data()
        parent.resizable(width=True, height=True)
        self.configure(bg="white")
        datas = self.getData.getUserDaten()
        self.getData.UserDatemDb(datas[1])
        # Create the menu frame
        menu = tk.Frame(self)
        menu.config(background="#334257", height=100)
        menu.pack(fill="x")

        # Create labels for the menu
        limg = Image.open("Images/HomeBilder/traktor.png").resize((50, 50))
        self.lphoto = ImageTk.PhotoImage(limg)
        label1 = ttk.Label(menu, image=self.lphoto, background="#334257", foreground="#fff")
        label1.pack(side="left", pady=10, padx=10, expand=1)
        label1.bind("<Button 1>", func=self.parent.homePages)
        # Name Label
        page = tk.Label(menu, text=" H o m e P a g e ", background="#334257", fg="#fff",
                        font=("Arial", 18, "bold"))
        page.pack(side="left", pady=10, expand=1)
        eimg = Image.open("Images/HomeBilder/einkaufswagen.png").resize((50, 50))
        self.ephoto = ImageTk.PhotoImage(eimg)
        label_wg = ttk.Label(menu, image=self.ephoto, background="#334257", foreground="#fff")
        label_wg.pack(side="right", pady=10, padx=10, expand=1)
        label_wg.bind("<Button 1>", func=self.parent.einkaufsWagen)

        dataFram = tk.Frame(self, height=40)
        dataFram.pack(fill="x")
        # datas = self.getData.getUserDaten()
        fontStyle = ("Arial", 16, "bold italic")
        usernameM = datas[0]

        userLabelM = tk.Label(dataFram, text=f"Name: {usernameM}", font=fontStyle)
        userLabelM.pack(side="left", expand=1)

        budgetM = datas[3]
        budgetMlabel = tk.Label(dataFram, text=f"budget: {budgetM} €", font=fontStyle)
        budgetMlabel.pack(side="left", expand=1)
        # Create the main frame
        self.main = tk.Frame(self)
        self.main.pack(fill="both")
        
        # Create the card container frame
        self.card_container = ctk.CTkScrollableFrame(self.main, height=800, width=1000, fg_color="#fff")
        self.card_container.pack(fill="y", side="left", expand=1)

        # Load card data from Excel
        self.card_data = self.getData.getData_card()

        # Create cards
        self.photo_list = [0, ]  # List to store PhotoImage objects
        for card in self.card_data:
            img_path = f"./Images/{card[8]}"
            img = Image.open(img_path).resize((250, 250))
            photo = ImageTk.PhotoImage(img)
            self.photo_list.append(photo)  # Store PhotoImage object in the list
            self.create_card(card)

        # Create footer frame
        footer = tk.Frame(self, background="#334257", height=150)
        footer.pack(fill="x")

    def create_card(self, data):
        if data[7] != 0:
            card = tk.Frame(self.card_container, height=300)
            # image Traktor

            cardImg = tk.Label(card, image=self.photo_list[len(self.photo_list) - 1])
            cardImg.place(x=20, y=10)
            cardImg.bind("<Button>",
                         lambda event, data=data, img=self.photo_list[len(self.photo_list) - 1]: self.showPhoto(data,
                                                                                                                img))
            herLabel = tk.Label(card, text=f"Hersteller: {data[1]}", font=("Arial", 18, "bold"))
            herLabel.place(x=350, y=5)
            hr = ttk.Separator(card)
            hr.place(x=350, y=40, width=200, height=10)

            typLabel = tk.Label(card, text=f"Typ: {data[2]}", font=("Arial", 16, ""))
            typLabel.place(x=350, y=50)

            psLabel = tk.Label(card, text=f"Ps: {data[3]}", font=("Arial", 16, ""))
            psLabel.place(x=350, y=80)

            kmHLabel = tk.Label(card, text=f"Km/h: {data[4]} ", font=("Arial", 16, ""))
            kmHLabel.place(x=350, y=110)

            bjLabel = tk.Label(card, text=f"Baujahr: {data[6]}", font=("Arial", 16, ""))
            bjLabel.place(x=350, y=150)

            priceLabel = tk.Label(card, text=f"Preis: {data[5]}")
            priceLabel.place(x=600, y=40, width=150)

            buyBtn = ctk.CTkButton(card, text="Add to Cart")
            buyBtn.bind("<Button-1>", lambda event, data=data: self.button_clicked(data))
            buyBtn.place(x=600, y=150)
            hr = ttk.Separator(self.card_container)
            hr.pack()
            card.pack(fill="x")

    def button_clicked(self, e):
        self.save_data(e)

    def save_data(self, id):
        with open("./Daten/login.csv", "r") as userData:
            user = userData.readline().split(" | ")[1]
        self.getData.insert_to_cart(user=user, vk=id[9], pid=id[0])
        self.checkFrame()

    def checkFrame(self):
        frameSecseful = tk.Frame(self.main)
        frameSecseful.place(y=10, x=950, width=300, height=40)

        img = Image.open("Images/HomeBilder/checked.png").resize((20, 20))
        self.photoS = ImageTk.PhotoImage(img)
        pfile = tk.Label(frameSecseful, image=self.photoS)
        pfile.pack(side="left", expand=1, padx=5)

        added = tk.Label(frameSecseful, text="Deine produkt schon in einkaufsWagen!")
        added.pack(side="left", expand=1)
        self.parent.after(2000, frameSecseful.destroy)

    def showPhoto(self, card, img):
        self.main.pack_forget()
        print(card)
        card_frame = tk.Frame(self)
        card_frame.pack(padx=50, fill="both", expand=1, pady=10)
        card_frame.grid_columnconfigure(0, weight=1)
        card_frame.grid_columnconfigure(1, weight=5)

        image_label = ttk.Label(card_frame, image=img)
        image_label.image = img  # Store a reference to the image
        image_label.pack()

        info_frame = tk.Frame(card_frame)
        info_frame.pack()

        name_label = ttk.Label(info_frame, text=f"Herrsteller :{card[2]}\tps :{card[3]}", font=font_h1)
        name_label.pack(fill="x")
        hr = ttk.Separator(info_frame)
        hr.pack(fill="x")

        beschreibung_label = ttk.Label(info_frame, font=font_p,text=
    f"{card[2]} {card[3]} ist ein leistungsstarker Traktor mit einer Leistung\n"
    f"von {card[4]} PS. Mit einer Höchstgeschwindigkeit von {card[6]} km/h ist er ein\n"
    "zuverlässiges und effizientes Arbeitsgerät für landwirtschaftliche Aufgaben.\n\n"
    f"Der Traktor wurde von {card[2]}, einem renommierten Hersteller von Landmaschinen,\n"
    "entwickelt. Mit seiner robusten Konstruktion und hochwertigen Komponenten bietet\n"
    f"der {card[3]} eine hohe Leistungsfähigkeit und Langlebigkeit. Er eignet sich\n"
    "ideal für verschiedene landwirtschaftliche Anwendungen wie das Ziehen schwerer\n"
    "Lasten oder das Pflügen von Feldern.\n\n"
    f"Der {card[2]} {card[3]} verfügt über moderne Funktionen und Technologien, die die\n"
    "Bedienung erleichtern und die Produktivität steigern. Mit seiner komfortablen Kabine\n"
    "und ergonomischen Ausstattung sorgt er für eine angenehme Arbeitsumgebung für den\n"
    "Fahrer.\n\n"
    "Insgesamt ist der Claas 95E ein leistungsstarker und zuverlässiger Traktor, der die\n"
    "Anforderungen anspruchsvoller landwirtschaftlicher Arbeiten erfüllt."
)

        beschreibung_label.pack(fill="x")

        info_preis_frame = tk.Frame(info_frame)
        info_preis_frame.pack(fill="both", pady=20, padx=20)
        info_preis_frame.grid_columnconfigure((0, 1, 2, 3, 4), weight=2)
        preis_label = tk.Label(info_preis_frame, text=card[6])
        preis_label.grid(row=0, column=0, sticky="ns")

        add_button = ttk.Button(info_preis_frame, text="Add to cart")
        add_button.grid(row=0, column=4, sticky="ns")
        add_button.bind("<Button-1>", lambda event, card=card: self.button_clicked(card))
